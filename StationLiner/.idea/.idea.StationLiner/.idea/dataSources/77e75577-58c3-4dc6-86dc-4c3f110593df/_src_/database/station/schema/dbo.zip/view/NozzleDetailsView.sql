CREATE VIEW NozzleDetailsView AS SELECT nr.*, pn.ProductId, pn.PumpId,pn.TankId from  NozzleReadings nr Left Join PumpNozzles pn on nr.NozzleId = pn.id
GO
